package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginScreen extends AppCompatActivity {
    private EditText userName;
    private EditText passWord;
    private Button loginBtn;
    private Button createBtn;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        userName = findViewById(R.id.userName);
        passWord = findViewById(R.id.passWord);
        loginBtn = findViewById(R.id.loginBtn);
        createBtn = findViewById(R.id.createBtn);
        databaseHelper = new DatabaseHelper(this);

        createBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String user = userName.getText().toString();
                String pass = passWord.getText().toString();


                if(user.equals("")||pass.equals(""))
                    Toast.makeText(LoginScreen.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(pass)){
                        Boolean checkuser = databaseHelper.checkusername(user);
                        if(checkuser==false){
                            Boolean insert = databaseHelper.insertData(user, pass);
                            if(insert==true){
                                Toast.makeText(LoginScreen.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),DisplayScreen.class);
                                startActivity(intent);
                            }else{
                                Toast.makeText(LoginScreen.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(LoginScreen.this, "User already exists! please sign in", Toast.LENGTH_SHORT).show();
                        }
                    }
                } }
        });



        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = userName.getText().toString();
                String pass = passWord.getText().toString();

                if(user.equals("")||pass.equals(""))
                    Toast.makeText(LoginScreen.this, "Please enter Username & Password", Toast.LENGTH_SHORT).show();
                else{
                    Boolean checkuserpass = databaseHelper.checkusernamepassword(user, pass);
                    if(checkuserpass==true){
                        Toast.makeText(LoginScreen.this, "Sign in Successful", Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(getApplicationContext(), DisplayScreen.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(LoginScreen.this, "Invalid Username Or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}