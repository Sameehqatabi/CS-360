package com.example.inventoryapp;

import java.util.ArrayList;
import java.util.Date;

public class Item {

    public static ArrayList<Item> itemArrayList = new ArrayList<>();

    private static int id;
    private String item;
    private String quantity;
    private Date deleted;

    public Item(int id, String item, String quantity, Date deleted) {
        this.id = id;
        this.item = item;
        this.quantity = quantity;
        this.deleted = deleted;
    }

    public Item(int id, String item, String quantity) {
        this.id = id;
        this.item = item;
        this.quantity = quantity;
        deleted = null;
    }


    public static int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public Date getDeleted() {
        return deleted;
    }

    public void setDeleted(Date deleted) {
        this.deleted = deleted;
    }
}
