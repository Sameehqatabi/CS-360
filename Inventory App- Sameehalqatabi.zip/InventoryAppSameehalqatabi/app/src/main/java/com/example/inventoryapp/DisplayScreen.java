package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

public class DisplayScreen extends AppCompatActivity {
    private ImageButton editbtn;
    private ListView itemListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_screen);
        initWidgets();
        setItemAdapter();





    }

    private void initWidgets() {
        itemListView = findViewById(R.id.itemListView);
    }

    private void setItemAdapter() {
        ItemAdapter itemAdapter = new ItemAdapter(getApplicationContext(), Item.itemArrayList);
        itemListView.setAdapter(itemAdapter);
    }

    public void newItem(View View){
        Intent newItemIntent = new Intent(this, AddItem.class);
        startActivity(newItemIntent);
    }
}