package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddItem extends AppCompatActivity {
    private Button cancelBtn;
    private EditText edititemText;
    private EditText editQuantityNum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);
        initWidgets();

        cancelBtn = findViewById(R.id.cancelBtn);
        edititemText = findViewById(R.id.edititemText);
        editQuantityNum = findViewById(R.id.editQuantityNum);


        cancelBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(AddItem.this, DisplayScreen.class);
                startActivity(intent);
            }
        });


    }

    private void initWidgets() {
        edititemText = findViewById(R.id.edititemText);
        editQuantityNum = findViewById(R.id.editQuantityNum);
    }
    public void saveItem(View view){
        String item = String.valueOf(edititemText.getText());
        String quantity = String.valueOf(editQuantityNum.getText());

        int id = Item.itemArrayList.size();
        Item newItem = new Item(id, item, quantity);
        Item.itemArrayList.add(newItem);
        finish();

    }
}